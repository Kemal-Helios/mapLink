<?php

//for contact
include 'Admin/contact.php';

//Routes
$lang   =   "includes/languages/";
$tpl    =   "includes/templates/";
$func    =  "includes/functions/";
$css    =   "layout/css/";
$js     =   "layout/js/";



//Include The Important Files
include     $func   .   "function.php";
include     $lang   .   "en.php";
include     $tpl    .   "header.php";
/*if(!isset($noNavar)) { include     $tpl    .   "navbar.php";}*/

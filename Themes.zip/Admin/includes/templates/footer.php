            <div class="footer">
                
            </div>
        <script src="<?php echo $js ?>jquery-3.2.1.min.js"></script>
        <script src="<?php echo $js ?>popper.js"></script>
        <script src="<?php echo $js ?>bootstrap.min.js"></script>
        <script src="<?php echo $js ?>html5shiv.min.js"></script>
        <script src="<?php echo $js ?>jquery.nicescroll.min.js"></script>
        <script src="<?php echo $js ?>plugins.js"></script>   
    </body>
</html>
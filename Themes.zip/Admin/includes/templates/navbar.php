<?php

?>
<nav class="navbar navbar-dark bg-dark">
  <div class="container">
      <a class="navbar-brand" href="../index.php">Shortcuts</a>
      <ul class="nav nav-tabs">
          <li class="nav-item">
            <a class="nav-link " href="Admin.php?adoff=Manage">Admin</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="dashboard.php">Control Board</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="websites.php">Websites</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="delimg.php">Images</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="categories.php">Categories</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="comment.php">Comment</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="dilMessEma.php">Message</a>
          </li>
          <li class="nav-item">
            <a class="nav-link disabled" href="logout.php">Logout</a>
          </li>
      </ul>
  </div>
</nav>






<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container">
        <a class="navbar-brand" href="index.php">نيدلينك</a>
        <div class="colla navbar-collapse" >
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="categories.php?mod=imgDesign">تصميم الرسومات </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="categories.php?mod=webDesign">تصميم ويب</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="categories.php?mod=programmingWeb">برمجة ويب</a>
                </li>
                <li class="nav-item">
                    <div id="dropdown-x" class="ddmenu">
                         برمجة تطبيقات
                        <ul>
                            <li><a href="categories.php?mod=programmingDesktop">سطح المكتب</a></li>
                            <li><a href="categories.php?mod=Mobile">موبايل</a></li>
                            <li><a href="categories.php?mod=More">المزيد</a></li>
                        </ul>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</nav>
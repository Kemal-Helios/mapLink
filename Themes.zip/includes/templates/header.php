<!DOCTYPE html>
<html lang="ar">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="apple-mobile-web-app-capable" content="yes">
        <title><?php getTitle()?></title>
        <link href="https://fonts.googleapis.com/css?family=Amiri:700" rel="stylesheet">
        <link rel="stylesheet" href="<?php echo $css ?>font-awesome.min.css" />
        <link rel="stylesheet" href="<?php echo $css ?>bootstrap.min.css" />
        <link rel="stylesheet" href="<?php echo $css ?>style.css" />
    </head>
<body>
  
    
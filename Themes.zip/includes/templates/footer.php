    <div class="footer text-center">
        <div class="container"> 
            <div class="row">
                <div class="col-md-4">
                    <h4>الأقسام</h4>
                     <ul class="fotter-list">
                        <li><a href="categories.php?mod=imgDesign">تصميم الرسومات</a></li>
                        <li><a href="categories.php?mod=webDesign">تصميم الويب</a></li>
                        <li><a href="categories.php?mod=programmingWeb">برمجة ويب</a></li>
                    </ul>
                    <ul class="fotter-list mar-left">
                        <li><a href="categories.php?mod=programmingDesktop">سطح المكتب</a></li>
                        <li><a href="categories.php?mod=Mobile">موبايل</a></li>
                        <li><a href="categories.php?mod=More">المزيد</a></li>
                    </ul>
                    <button type="button" class="btn btn-outline-info up btn-more"><i class="fa fa-angle-double-up" aria-hidden="true"></i></button>
                </div>
                <div class="col-md-4">
                    <h4>تابعنا</h4>
                    <div class="follow">
                        <a href="https://www.facebook.com/kamal.tabash"><i class="fa fa-facebook-square fa-2x" aria-hidden="true"></i></a> 
                        <a href="https://twitter.com/KemalTabas"><i class="fa fa-twitter-square fa-2x" aria-hidden="true"></i></a>
                        <a href="https://codepen.io/Helios1/"><i class="fa fa-codepen fa-2x" aria-hidden="true"></i></a>
                    </div>
                    
                </div>
                <div class="col-md-4">
                    <h4>أبقى متصل</h4>
                   <div class="Contact-us">
                       <form action="insert.php?mod=insertEmail" method="POST">
                            <input type="text" name="email" class="form-control trans" placeholder=" الأيميل : لتبقى متصل بكل تحديث">
                            <input type="submit" class="form-control btn btn-success" value="أرسال">
                        </form>
                   </div>
                </div>
            </div>
        </div>    
        <div class="copyright">
            <span class="design">Development by Kamal Tabsh &copy; 2017</span>
        </div>
                 
    </div>
        <script src="<?php echo $js ?>jquery-3.2.1.min.js"></script>
        <script src="<?php echo $js ?>jquery.nicescroll.min.js"></script>
        <script src="<?php echo $js ?>popper.js"></script>
        <script src="<?php echo $js ?>bootstrap.min.js"></script>
        <script src="<?php echo $js ?>html5shiv.min.js"></script>
        <script src="<?php echo $js ?>scrollComm.js"></script>
        <script src="<?php echo $js ?>plugins.js"></script>   
    </body>
</html>